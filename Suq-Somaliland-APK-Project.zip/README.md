# Suq Somaliland - Android APK

هذا المشروع يحوّل موقع GitHub Pages الحالي إلى تطبيق Android بسيط باستخدام WebView.

الموقع:
https://jawidagan808-glitch.github.io/suq-somaliland/

## إنشاء APK مجاناً عبر GitHub Actions
1. ارفع محتويات هذا المشروع إلى مستودع GitHub جديد.
2. ادخل إلى تبويب Actions.
3. شغّل workflow باسم Build APK إذا لم يبدأ تلقائياً.
4. بعد نجاح البناء، افتح العملية الناجحة ثم Artifacts.
5. نزّل Suq-Somaliland-APK، فك الضغط، ثم ثبّت app-debug.apk على هاتف Android.

لا تحتاج إلى دفع المال لبناء APK بهذه الطريقة.
